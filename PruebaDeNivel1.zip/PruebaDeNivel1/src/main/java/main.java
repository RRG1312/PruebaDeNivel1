import java.io.IOException;
import java.util.Scanner;

public class main {
    public static void main(String[] args) throws IOException {
        Menu menu = new Menu();
        menu.init();
    }

}
